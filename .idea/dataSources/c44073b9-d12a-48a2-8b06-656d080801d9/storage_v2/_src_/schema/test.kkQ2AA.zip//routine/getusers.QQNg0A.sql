create procedure getUsers(IN argName varchar(20))
  BEGIN
    SELECT * FROM users2 WHERE name = argName;
  END;

