create procedure getCount()
  BEGIN
    SELECT count(*) from users2;
    SELECT count(*) from users;
  END;

