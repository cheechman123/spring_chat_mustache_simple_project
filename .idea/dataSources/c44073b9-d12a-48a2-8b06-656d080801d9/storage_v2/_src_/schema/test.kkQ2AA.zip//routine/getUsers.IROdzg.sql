CREATE PROCEDURE getUsers(IN argName VARCHAR(20))
  BEGIN
    SELECT * FROM users2 WHERE name = argName;
  END;

