create procedure MaxPassword(OUT Max int)
  BEGIN
  SELECT max(password) into Max from users;
END;

