create procedure UsersCount(OUT Count int)
  BEGIN
    SELECT count(*) into count from users2;
  END;

